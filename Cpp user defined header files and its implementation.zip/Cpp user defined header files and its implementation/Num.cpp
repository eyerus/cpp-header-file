#include "Num.h"
Num :: Num() : num(0){}
Num :: Num(int n): num(n){}
int Num :: square()
{
	return num * num;
}