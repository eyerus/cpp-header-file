#include <iostream>
#include <Num.h>


using namespace std;

int main(){
	Num n(35);
	cout << n.square() << endl;
	return 0;
}