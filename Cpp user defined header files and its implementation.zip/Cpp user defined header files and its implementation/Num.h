class Num{
	private int num;
	public Num(int n);
	int getNum();
	int square(num);
};